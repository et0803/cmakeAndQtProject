# QML-Camera
Simple Qt Quick GUI to display primary USB camera and take still pictures. The last pictures could also be shown in a Listview with review mode.

Just click on the live image to take a picture. Click on old pictures to see them in big.


# What you need
- Qt5.4
- Linux (should also run on windows mac.. but check rights for saving images into build folder)
