dual-camera
-----------

Displays two camera images on the screen simultaneously.

**Desktop:** The two cameras must be connected to different USB buses in order to be accessed simultaneously by libv4l.

**Android:** The OpenCV accessor to the Android API does not support multiple simultaneous camera access yet, so the sample doesn't work on Android.

For build instructions, see [../README.md](../README.md).

