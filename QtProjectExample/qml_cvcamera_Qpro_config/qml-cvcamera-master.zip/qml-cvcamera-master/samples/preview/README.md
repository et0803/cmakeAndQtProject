preview
-------

Displays the camera image on the screen.

For build instructions, see [../README.md](../README.md).

